# Heart_Attack_Prediction
This is a heart attack prediction using Random Forest classifier and deployed in streamlit
